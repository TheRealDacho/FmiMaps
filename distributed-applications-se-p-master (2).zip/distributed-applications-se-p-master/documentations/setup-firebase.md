# Google Firebase
Setup Google Firebase



#
### Steps

* Step One - install nodejs: 
  * [Download link](nodejs.org)


  
* Step two - install firebase: 
  * Command Line - npm install -g firebase-tools



* Step three - login: 
  * Command Line - firebase login
  
  
  
* Step fourth - setup firebase project: 
  * Command Line - firebase init funtions